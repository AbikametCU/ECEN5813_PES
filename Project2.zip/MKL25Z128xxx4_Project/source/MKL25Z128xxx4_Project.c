/*
 * Copyright 2016-2018 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/**
 * @file    MKL25Z128xxx4_Project.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "ring.h"
//#include "pin_mux.h"
//#include "clock_config.h"
#include "MKL25Z4.h"
//#include "fsl_debug_console.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */

//Array to keep track of the number of characters that have been typed
int Char_Count[256];

//Ring used for the application to keep track of which characters were pressed
ring_t *CharCountRing = NULL;

//Ring used to transmit data to the terminal via interrupts
ring_t *CharPrintRing = NULL;

//struct ASCII ASCII_COUNT;

//ASCII_COUNT.RINGBOI = Ring_init(100);


#define CORE_CRITICAL_SECTION(yourcode) \
  {                                     \
    DisableIRQ(UART0_IRQn);             \
    {                                   \
      yourcode                          \
    }                                   \
    EnableIRQ(UART0_IRQn);              \
  }

static uint32_t global_flag_boi;

#define UART_RECV_CHAR_FLAG 1
#define SET_RECV_EVENT() global_flag_boi |= UART_RECV_CHAR_FLAG
#define UART_TRANS_CHAR_FLAG 2
#define SET_TRANS_EVENT() global_flag_boi |= UART_TRANS_CHAR_FLAG

#define CLEAR_ALL_UART_EVTS() global_flag_boi=0;



#define ASCII_ZERO 48

#define BLOCKING_MODE_ENABLED 0
#define ENABLE_CHARACTER_COUNT_APPLICATION 1

void Uart_Init(void){
	//System Clock Gating Control Register 5
	//Port A Clock Gate Control--This bit controls the clock gate to the Port A module
	SIM->SCGC5 |= SIM_SCGC5_PORTA(1);

	//System Clock Gating Control Register 4 (SIM_SCGC4)
	//UART0 Clock Gate Control--This bit controls the clock gate to the UART0 module.
	SIM->SCGC4 |= SIM_SCGC4_UART0(1);

	//UART0 CLOCK SOURCE SET--Selects the clock source for the UART0 transmit and receive clock.
	//00 Clock disabled
	//01 MCGFLLCLK clock or MCGPLLCLK/2 clock
	SIM->SOPT2 |= SIM_SOPT2_UART0SRC(1);


	//Pin Control register for pin1 and pin2, alternative 2 set for the UART RX (pcr1) and TX(pcr2)
	PORTA->PCR[1] |= PORT_PCR_MUX(2);
	PORTA->PCR[2] |= PORT_PCR_MUX(2);

	//LED pin setup
	SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;
	GPIOD->PSOR |= (1<<1);
	GPIOD->PDDR |= (1<<1);
	PORTD->PCR[1] |= PORT_PCR_MUX(1);

	//Disable the Transmitter and Receiver before you set the BUAD rate
	//UART Control Register 2
	//When the UART is configured for single-wire operation (LOOPS = RSRC = 1), TXDIR controls the
	//direction of traffic on the single UART communication line (TxD pin).
	//TE can also queue an idle character by clearing TE then setting TE while a transmission is in progress.
	UART0->C2 |= UART_C2_TE(0);
	UART0->C2 |= UART_C2_RE(0);

//	This register, along with UART_BDL, controls the prescale divisor for UART baud rate
//	generation. To update the 13-bit baud rate setting [SBR12:SBR0], first write to
//	UART_BDH to buffer the high half of the new value and then write to UART_BDL. The
//	working value in UART_BDH does not change until UART_BDL is written.
	//UART0->BDH |= UART0_BDH_SBR(0);


//	UART_BDL is reset to a non-zero value, so after reset the baud rate generator remains
//	disabled until the first time the receiver or transmitter is enabled; that is, UART_C2[RE]
//	or UART_C2[TE] bits are written to 1.

	//These 13 bits in SBR[12:0] are referred to collectively as BR. They set the modulo divide rate for the
    //UART baud rate generator. When BR is cleared, the UART baud rate generator is disabled to reduce
    //supply current. When BR is 1 - 8191, the UART baud rate equals BUSCLK/(16×BR).
	uint8_t Serial_Buad_Rate = (DEFAULT_SYSTEM_CLOCK)/(115200 * (15+1));
	UART0->BDL |= UART_BDL_SBR(Serial_Buad_Rate+1);

	UART0->C2 |= UART_C2_TE(1);
	UART0->C2 |= UART_C2_RE(1);

#if BLOCKING_MODE_ENABLED
	UART0->C2 |= UART_C2_RIE(0);
#else
	//Enable Uart Interrupts
	NVIC_EnableIRQ(UART0_IRQn);

	//enable receive interrupts if non-blocking mode
	UART0->C2 |= UART_C2_RIE(1);

	//enable transmit interrupts if non-blocking mode
	UART0->C2 |= UART_C2_TIE(1);

#endif
}

void UartReadyForTransmit(){
	//Block until the Transmit Data Register Empty Flag and Transmission Complete Flag are set
	while( !(UART0->S1 & UART_S1_TDRE_MASK) && !(UART0->S1 & UART_S1_TC_MASK) );
}

void UartPutChar(char input){
	UartReadyForTransmit();

	//read the uart data register
	UART0->D = input;

	return;
}

void UartReadyForReceive(){
	//Receive Data Register Full Flag (RDRF) becomes set whenever the
	//receive data buffer is full. To clear RDRF, read the UART data register 0=empty, 1=full.
	//Wait for the buffer to become full.
	while( !(UART0->S1 & UART_S1_RDRF_MASK) );
}

char UartGetChar(){
	UartReadyForReceive();

	return UART0->D;
}

void UART_PRINT(char *CharsToPrint, int SizeOfCharArray){
	for (int i = 0; i<SizeOfCharArray; i++){
		UartPutChar(CharsToPrint[i]);
	}
}

void UART_NEW_LINE(){
	UartPutChar('\n');
	UartPutChar('\r');
}

void CountChar(ring_t *ringBuf){
	int TotalEntries = entries(ringBuf);
	int OutPosition = ringBuf->Outi;
	//Loop through the number of entries in the buffer, since outi moves as the entries are
	//removed from the buffer, start the loop at where the last out position was located
	for (int entry = OutPosition; entry < (TotalEntries+OutPosition); entry++){
		char CharCheck=ringBuf->Buffer[entry];
		for(int ASCII_VAL = 0; ASCII_VAL<256; ASCII_VAL++){
			//Check to see what ascii values are within the buffer
			if (CharCheck==ASCII_VAL){
				Char_Count[ASCII_VAL]++;
				char removedItem[1];
				remove_element(ringBuf, removedItem);
			}
			//Print the character and the value if the value is greater than 0
			if (Char_Count[ASCII_VAL]>0){
				if(Char_Count[ASCII_VAL]>=100){
					int ones = Char_Count[ASCII_VAL]%10;
					int tens = (Char_Count[ASCII_VAL]%100)/10;
					int hundreds = Char_Count[ASCII_VAL]/100;
					insert(CharPrintRing, (ASCII_VAL));
					insert(CharPrintRing, '=' );
					insert(CharPrintRing, (hundreds + ASCII_ZERO) );
					insert(CharPrintRing, (tens + ASCII_ZERO) );
					insert(CharPrintRing, (ones + ASCII_ZERO) );
					insert(CharPrintRing, '\n');
					insert(CharPrintRing, '\r');
				}
				else if(Char_Count[ASCII_VAL]>=10){
					int ones = Char_Count[ASCII_VAL]%10;
					int tens = Char_Count[ASCII_VAL]/10;
					insert(CharPrintRing, (ASCII_VAL));
					insert(CharPrintRing, '=' );
					insert(CharPrintRing, (tens + ASCII_ZERO) );
					insert(CharPrintRing, (ones + ASCII_ZERO) );
					insert(CharPrintRing, '\n');
					insert(CharPrintRing, '\r');
				}
				else if(Char_Count[ASCII_VAL]<10){
					insert(CharPrintRing, (ASCII_VAL));
					insert(CharPrintRing, '=' );
					insert(CharPrintRing, (Char_Count[ASCII_VAL] + ASCII_ZERO) );
					insert(CharPrintRing, '\n');
					insert(CharPrintRing, '\r');
				}
			}
		}
	}
}

void Uart_Transmit (char transmitChar){
	UART0->D = transmitChar;
}

void ApplicationTitlePrint(){
	insert(CharPrintRing, '-');
	insert(CharPrintRing, '-');
	insert(CharPrintRing, 'a');
	insert(CharPrintRing, 'p');
	insert(CharPrintRing, 'p');
	insert(CharPrintRing, '-');
	insert(CharPrintRing, '-');
	insert(CharPrintRing, '\r');
	insert(CharPrintRing, '\n');
}
static char recvData;
void UART0_IRQHandler(){
	CORE_CRITICAL_SECTION(
//If there was a receive interrupt
		if(UART0->S1 & UART_S1_RDRF_MASK){
			recvData = UART0->D;
#if ENABLE_CHARACTER_COUNT_APPLICATION
			//if the character counting application is being utilized, add the entry to the count ring
			insert(CharCountRing, recvData);

			//enable transmit interrupts if you insert something into the buffer
			UART0->C2 |= UART_C2_TIE(1);
#else
			//if the character count application is NOT being utilized, just use the print ring
			insert(CharPrintRing, recvData);
#endif
		}

//Determine how many entries are within the ring to see if you need to transmit anything
#if ENABLE_CHARACTER_COUNT_APPLICATION
		int TotalEntries = entries(CharCountRing);
#else
		int TotalEntries = entries(CharPrintRing);
#endif


//If there was a transmit interrupt
		if( (UART0->S1 & UART_S1_TDRE_MASK) && ( TotalEntries > 0) ){
#if ENABLE_CHARACTER_COUNT_APPLICATION
			ApplicationTitlePrint();
			CountChar(CharCountRing);
#endif
		}
		else{
			//disable transmit interrupts if when there is nothing to transmit
			UART0->C2 &= ~UART_C2_TIE_MASK;
		}
	)
}
int main(void) {

	CharCountRing = Ring_init(100);
	CharPrintRing = Ring_init(100);
    Uart_Init();
    while(1) {
#if BLOCKING_MODE_ENABLED
    	char MyChar = UartGetChar();
    	UartPutChar(MyChar);
#else
    	char removeItem2[1];
		int TotalApplicationEntries = entries(CharPrintRing);
		int OutPosition = CharPrintRing->Outi;
		if(TotalApplicationEntries>0 && (UART0->S1 & UART_S1_TC_MASK) ){
			Uart_Transmit(CharPrintRing->Buffer[OutPosition]);
			remove_element(CharPrintRing, removeItem2);
		}
		if(TotalApplicationEntries == 0){
			for (int i = 0; i < 100000; i++);
				GPIOD->PTOR = (1<<1);
		}

#endif
    }
    return 0 ;
}
