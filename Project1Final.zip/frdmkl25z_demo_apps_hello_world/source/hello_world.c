

#include <stdio.h>
//#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "time.h"
#include <stdint.h>
#include "AllocateMemory.h"
#include "DisplayMemory.h"
#include "VerifyPattern.h"
#include "WritePattern.h"
#include "InvertMemory.h"
#include "WriteMemory.h"
#include "FreeMemory.h"
#include "Project1.h"


#define CORE_CLOCK 48000000


void SysTick_Handler(void)  {
	Number_Of_Reloads++;
}

void InitSysTick(){
	//Have the clock rollover every ms
	SysTick_Config(SystemCoreClock/1000);
}

void strInput(char str[]) {
  int i = 0;
#if LINUX_COMPILATION
  while(str[i-1]!='\n') {
#else
  while(str[i-1]!='\r') {
#endif
       str[i] = GETCHAR();
       PUTCHAR(str[i]);
       i++;
    //}
  }
  str[i] = '\0';
}

int StrCmp(char *strg1, char *strg2)
{
    while( ( *strg1 != '\0' && *strg2 != '\0' ) && *strg1 == *strg2 )
    {
        strg1++;
        strg2++;
    }

    if(*strg1 == *strg2)
    {
        return 0; // strings are identical
    }

    else
    {
        return *strg1 - *strg2;
    }
}

char* StrStr(char *str, char *substr)
{
	  while (*str != '\0')
	  {
		    char *Begin = str;
		    char *pattern = substr;

		    // If first character of sub string match, check for whole string
		    while ( (*str != '\0') && (*pattern != '\0') && (*str == *pattern) )
                    {
			      str++;
			      pattern++;
		    }
		    // If complete sub string match, return starting address
		    if (*pattern == '\0'){
                        return Begin;
                    }

		    str = Begin + 1;	// Increament main string
	  }
	  return NULL;
}


struct FunctionLUT{
    char *FunctionType;
    //Function Pointer used to point to the correct function to use based off the user's input
    void (*FunctionName)(char*, struct UserData*);
};

int IsChar(char c){
    if( (c>='a' && c<='z') || (c>='A' && c<='Z'))
        return 1;
    else
        return 0;
}

void Interpret_User_Input(char* User_Input, struct UserData *USERDATA_PTR){
    if( (StrCmp(User_Input, "Help\r") == 0) ){
	#if LINUX_COMPILATION
	printf("Please enter one of the following commands: Allocate Memory [Number of Bytes]\r\n"
               "                                            Free Memory-Frees all allocated memory\r\n"
               "                                            Display Memory (optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] (optional number of memory words to display)\r\n"
               "                                            Write Memory (optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] [Value to Write]\r\n"
               "                                            Invert [Address to Invert Memory at]\r\n"
               "                                            Wpattern(optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] [seed value]\r\n"
               "                                            Verify Pattern (optional -o option to specify offset instead of hex) [Memory Address as an integer offset starting from 0 if -0 option was chose or as a hex address] [seed value] (optional length of patterns to verify at multiple addresses)\r\n"
               "                                            Exit\r\n");

	#else
	PRINTF("Please enter one of the following commands: Allocate Memory [Number of Bytes]\r\n"
               "                                            Free Memory-Frees all allocated memory\r\n"
               "                                            Display Memory (optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] (optional number of memory words to display)\r\n"
               "                                            Write Memory (optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] [Value to Write]\r\n"
               "                                            Invert [Address to Invert Memory at]\r\n"
               "                                            Wpattern(optional -o option to specify offset instead of hex address) [Memory Address as an integer offset starting from 0 if -o option was chosen or as a hex value] [seed value]\r\n"
               "                                            Verify Pattern (optional -o option to specify offset instead of hex) [Memory Address as an integer offset starting from 0 if -0 option was chose or as a hex address] [seed value] (optional length of patterns to verify at multiple addresses)\r\n"
               "                                            Exit\r\n");
    #endif
    return;
    }



    else if( (StrCmp(User_Input, "Exit\r") == 0) ){
	#if LINUX_COMPILATION
	printf("Thank you!\r\n");
	#else
	PRINTF("Thank you!\r\n");
	#endif

        exit(0);
    }
}

int Handle_User_Input(char* User_Command, char* User_Input, struct FunctionLUT *FUNCTION_LUT_ARRAY_PTR, struct UserData *USERDATA_PTR){
    for(int i = 0; i < NUMBER_OF_USER_SELECTABLE_COMMANDS; i++){
        if ( StrCmp(User_Command, FUNCTION_LUT_ARRAY_PTR[i].FunctionType) == 0 ){
            FUNCTION_LUT_ARRAY_PTR[i].FunctionName(User_Input, USERDATA_PTR);
            return 1;
        }
    }
    return 0;
}


int main() {

	 /* Init board hardware. */
	    BOARD_InitPins();
	    BOARD_BootClockRUN();
	    BOARD_InitDebugConsole();

#if LINUX_COMPILATION
	    //Grab the current time
	    time_t Seed_Time = time(0);
#else
	    //Initialize the system clock Grab the current time
	    InitSysTick();
	    int Seed_Time = Number_Of_Reloads;
#endif

		USERDATA.Seed_Time = (uint32_t)Seed_Time;
		while(1){
		//-------------Get input from the user on what action to request from the server.------------
			int Welcome_Done_State = 0;
			int Input_State = 0;
			//struct UserData USERDATA;
			USERDATA.Allocate_State=0;
			USERDATA.Write_State=0;
			//Lookup Table structure
			struct FunctionLUT FUNCTION_LUT_ARRAY[] = {
														{.FunctionType = "Allocate", .FunctionName = &Interpret_Allocate_Input},
														{.FunctionType = "Write", .FunctionName = &Interpret_Write_Input},
														{.FunctionType = "Invert", .FunctionName = &Interpret_Invert_Input},
														{.FunctionType = "Display", .FunctionName = &Interpret_Display_Input},
														{.FunctionType = "Help\r", .FunctionName = &Interpret_User_Input},
														{.FunctionType = "Exit\r", .FunctionName = &Interpret_User_Input},
														{.FunctionType = "Free", .FunctionName = &Interpret_Free_Input},
														{.FunctionType = "Wpattern", .FunctionName = &Interpret_WPattern_Input},
														{.FunctionType = "Verify", .FunctionName = &Interpret_Verify_Input},
													};

		 while(Input_State==0){
					USERDATA.Wpattern_Length = 0;
					USERDATA.Verify_Length=0;
					USERDATA.Invert_Length=0;
					char User_Input[100] = {0};
					char User_Input_CPY[100] = {0};
					if (Welcome_Done_State == 1){
				#if LINUX_COMPILATION
						printf("\r\nPlease enter a command or type 'Help' for a list of commands:");
				#else
						PRINTF("\r\nPlease enter a command or type 'Help' for a list of commands:");
				#endif
					}
					if(Welcome_Done_State == 0){
				#if LINUX_COMPILATION
						printf("ECEN5813-PES Project 1:Welcome to the Interactive Memory Manipulation Program, Please type a command. (or type help for Info):");
				#else
						PRINTF("ECEN5813-PES Project 1:Welcome to the Interactive Memory Manipulation Program, Please type a command. (or type help for Info):");
				#endif
						Welcome_Done_State = 1;
					}
					//grab user input and store into User_Input Char array
					strInput(User_Input);
					PRINTF("\r\nUSER_INPUT:%s\r", User_Input);
					//Make sure the user input the correct options
					memcpy(User_Input_CPY, User_Input, sizeof(User_Input_CPY));
					char *User_Command_Choice = strtok(User_Input_CPY, " ");
					int ReturnVal = Handle_User_Input(User_Command_Choice, User_Input, FUNCTION_LUT_ARRAY, &USERDATA);
					if (ReturnVal == INVALID){
				#if LINUX_COMPILATION
					printf("INVALID INPUT: Please enter a proper command or type 'Help' for a list of commands and usage:\r\n");
				#else
					PRINTF("\r\nINVALID INPUT: Please enter a proper command or type 'Help' for a list of commands and usage:\r\n");
				#endif
						continue;
					}
				}
			}
		}
