#ifndef INVERTMEMORY_H_   /* Include guard */
#define INVERTMEMORY_H_
#include "Project1.h"

void Invert_Memory(struct UserData* USERDATA_PTR);

void Interpret_Invert_Input(char* User_Input, struct UserData *USERDATA_PTR);

#endif