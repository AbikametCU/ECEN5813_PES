#ifndef DISPLAYMEMORY_H_   /* Include guard */
#define DISPLAYMEMORY_H_
#include "Project1.h"

void Display_Memory(struct UserData* USERDATA_PTR);

void Interpret_Display_Input(char* User_Input, struct UserData *USERDATA_PTR);


#endif