#ifndef VERIFYPATTERN_H_   /* Include guard */
#define VERIFYPATTERN_H_
#include "Project1.h"

void Verify(struct UserData* USERDATA_PTR);

void Interpret_Verify_Input(char* User_Input, struct UserData *USERDATA_PTR);


#endif