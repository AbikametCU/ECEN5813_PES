#ifndef WRITEMEMORY_H_   /* Include guard */
#define WRITEMEMORY_H_
#include "Project1.h"

void Write_Memory(struct UserData* USERDATA_PTR);

void Interpret_Write_Input(char* User_Input, struct UserData *USERDATA_PTR);

#endif