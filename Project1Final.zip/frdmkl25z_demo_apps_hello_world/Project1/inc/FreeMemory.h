#ifndef FREEMEMORY_H_   /* Include guard */
#define FREEMEMORY_H_
#include "Project1.h"

void Free_Memory(uint32_t *MemoryPTR);

void Interpret_Free_Input(char* User_Input, struct UserData *USERDATA_PTR);

#endif