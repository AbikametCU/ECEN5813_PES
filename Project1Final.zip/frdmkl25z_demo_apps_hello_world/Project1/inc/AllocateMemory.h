#ifndef ALLOCATEMEMORY_H_   /* Include guard */
#define ALLOCATEMEMORY_H_
#include "Project1.h"

void Allocate_Memory(struct UserData* USERDATA_PTR);

void Interpret_Allocate_Input(char* User_Input, struct UserData *USERDATA_PTR);


#endif