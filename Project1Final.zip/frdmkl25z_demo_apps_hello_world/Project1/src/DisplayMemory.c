//-----------------------------------Linux definition 1 for linux build, 0 for FRDM build-----------
#define LINUX_COMPILATION 0

#if LINUX_COMPILATION

#include <stdio.h>

#else

#include "fsl_device_registers.h"
#include "fsl_debug_console.h"
#include "pin_mux.h"
#include "board.h"
#endif
//-------------------------------------------------------------------------------------------------

#include <stdio.h>
//#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include "Project1.h"

void Display_Memory(struct UserData* USERDATA_PTR){  
    if(USERDATA_PTR->Words_To_Display==0){
	#if LINUX_COMPILATION
	printf("Data Located at Address:%p = %d\r\n", USERDATA_PTR->GlobalPTR + USERDATA_PTR->Display_Offset_Bytes, *(USERDATA_PTR->GlobalPTR + USERDATA_PTR->Display_Offset_Bytes));
	#else
	PRINTF("Data Located at Address:%p = %d\r\n", USERDATA_PTR->GlobalPTR + USERDATA_PTR->Display_Offset_Bytes, *(USERDATA_PTR->GlobalPTR + USERDATA_PTR->Display_Offset_Bytes));
	#endif
    }
    else{
        for(int i = 0; i < USERDATA_PTR->Words_To_Display; i++){
			#if LINUX_COMPILATION
        		printf("Data Located at Address:%p = %d\r\n", USERDATA_PTR->GlobalPTR+(USERDATA_PTR->Display_Offset_Bytes+i), *(USERDATA_PTR->GlobalPTR + (USERDATA_PTR->Display_Offset_Bytes + i) ));
			#else
        		PRINTF("Data Located at Address:%p = %d\r\n", USERDATA_PTR->GlobalPTR+(USERDATA_PTR->Display_Offset_Bytes+i), *(USERDATA_PTR->GlobalPTR + (USERDATA_PTR->Display_Offset_Bytes + i) ));
			#endif
        } 
    }       
}

void Interpret_Display_Input(char* User_Input, struct UserData *USERDATA_PTR){
    char *token = strtok(User_Input, " "); 
    if ( StrCmp(token, "Display") != 0){
        return;
    }
    token = strtok(NULL, " ");
    token = strtok(NULL, " ");
    if (token == NULL){
		#if LINUX_COMPILATION
    	printf("ERROR:Please specify an address to write to\r\n");
		#else
    	PRINTF("ERROR:Please specify an address to write to\r\n");
#endif
    	return;
    }
    //If the user specified to write an offset of memory 
    if ( (StrCmp(token, "-o") == 0) ){
        token = strtok(NULL, " ");
        if (token == NULL){
#if LINUX_COMPILATION
        	printf("ERROR: Please specify a memory address offset and an integer to write to it\r\n");
#else
        	PRINTF("ERROR: Please specify a memory address offset and an integer to write to it\r\n");
#endif
        	return;
        }
        
        //Check to see if the user input a character and that the offset is less than the number of bytes the user allocated
        int Offset = atoi(token);
        if(IsChar(token[0]) == 1){
#if LINUX_COMPILATION
        	printf("ERROR: Please specify a proper memory address via an integer offset with 0 being the starting location up to %d\r\n", USERDATA_PTR->Bytes_To_Allocate);
#else
        	PRINTF("ERROR: Please specify a proper memory address via an integer offset with 0 being the starting location up to %d\r\n", USERDATA_PTR->Bytes_To_Allocate);
#endif
        	return;
        }
        else if(Offset > USERDATA_PTR->Bytes_To_Allocate){
#if LINUX_COMPILATION
        	printf("ERROR: Please specify a proper memory address via an integer offset with 0 being the starting location up to %d\r\n", USERDATA_PTR->Bytes_To_Allocate);
#else
        	PRINTF("ERROR: Please specify a proper memory address via an integer offset with 0 being the starting location up to %d\r\n", USERDATA_PTR->Bytes_To_Allocate);
#endif
        	return;
        }
        else{
            //Store the offset the user specified
            USERDATA_PTR->Display_Offset_Bytes=Offset;            
        }
        token = strtok(NULL, " ");
        if (token != NULL){
            int Words_To_Display = atoi(token);
            //Ensure the user typed an integer
            if (Words_To_Display == 0){
#if LINUX_COMPILATION
            	printf("ERROR: Please specify a nonzero integer to write to memory\r\n");
#else
            	PRINTF("ERROR: Please specify a nonzero integer to write to memory\r\n");
#endif
            	return;
            }
            else if( (Words_To_Display+USERDATA_PTR->Display_Offset_Bytes) > USERDATA_PTR->Bytes_To_Allocate ){
#if LINUX_COMPILATION
            	printf("ERROR: You cannot display words past the memory you allocated\r\n");
#else
            	PRINTF("ERROR: You cannot display words past the memory you allocated\r\n");
#endif
            	return;
            }
            USERDATA_PTR->Words_To_Display=Words_To_Display;
            if ( (USERDATA_PTR->Allocate_State == 0) || (USERDATA_PTR->Write_State == 0) ){
#if LINUX_COMPILATION
            	printf("ERROR: You can't display memory you haven't written or allocated");
#else
            	PRINTF("ERROR: You can't display memory you haven't written or allocated");
#endif
            }
            else{
                Display_Memory(USERDATA_PTR);
            }
            return;
        }
        else{
            USERDATA_PTR->Words_To_Display=0;
            if ( (USERDATA_PTR->Allocate_State == 0) || (USERDATA_PTR->Write_State == 0) ){
#if LINUX_COMPILATION
            	printf("ERROR: You can't display memory you haven't written or allocated");
#else
            	PRINTF("ERROR: You can't display memory you haven't written or allocated");
#endif
            }
            else{
                Display_Memory(USERDATA_PTR);
            }
            return;
        }
                
    }
    //If the user provided a hexidecimal address
    else{
        token[strlen(token)] = '\0';
        if (token == NULL){
#if LINUX_COMPILATION
        	printf("ERROR:Please specify an address to display\r\n");
#else
        	PRINTF("ERROR:Please specify an address to display\r\n");
#endif
        	return;
        }
        long int UserAddress = strtol(token, NULL, 16);
        //Check if the address the user provided is within range
        if ( (UserAddress >= (long int)USERDATA_PTR->GlobalPTR) && (UserAddress <= ((long int)USERDATA_PTR->GlobalPTR+USERDATA_PTR->Bytes_To_Allocate)) ){
            long int Offset = (UserAddress-(long int)USERDATA_PTR->GlobalPTR)/4;
            USERDATA_PTR->Display_Offset_Bytes=Offset;            
        }
        else{
#if LINUX_COMPILATION
        	printf("ERROR: Invalid address specified\r\n");
#else
        	PRINTF("ERROR: Invalid address specified\r\n");
#endif
        	return;
        }
        token = strtok(NULL, " ");
        if (token != NULL){
            int Words_To_Display = atoi(token);
            //Ensure the user typed an integer
            if (Words_To_Display == 0){
#if LINUX_COMPILATION
            	printf("ERROR: Please specify a nonzero integer to write to memory\r\n");
#else
            	PRINTF("ERROR: Please specify a nonzero integer to write to memory\r\n");
#endif
            	return;
            }
            else if( (Words_To_Display+USERDATA_PTR->Display_Offset_Bytes) > USERDATA_PTR->Bytes_To_Allocate ){
#if LINUX_COMPILATION
            	printf("ERROR: You cannot display words past the memory you allocated\r\n");
#else
            	PRINTF("ERROR: You cannot display words past the memory you allocated\r\n");
#endif
            	return;
            }
            USERDATA_PTR->Words_To_Display=Words_To_Display;            
            if ( (USERDATA_PTR->Allocate_State == 0) || (USERDATA_PTR->Write_State == 0) ){
#if LINUX_COMPILATION
            	printf("ERROR: You can't display memory you haven't written or allocated");
#else
            	PRINTF("ERROR: You can't display memory you haven't written or allocated");
#endif
            }
            else{
                Display_Memory(USERDATA_PTR);
            }
            return;
        }
        else{
            USERDATA_PTR->Words_To_Display=0;
            if ( (USERDATA_PTR->Allocate_State == 0) || (USERDATA_PTR->Write_State == 0) ){
#if LINUX_COMPILATION
            	printf("ERROR: You can't display memory you haven't written or allocated");
#else
            	PRINTF("ERROR: You can't display memory you haven't written or allocated");
#endif
            }
            else{
                Display_Memory(USERDATA_PTR);
            }
            return;
        }
    }       
}
