/*
 * Copyright 2016-2018 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/**
 * @file    PES_Project3.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_adc16.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "fsl_dmamux.h"
#include "fsl_dma.h"
#include<math.h>
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */

#define LED_INIT() LED_RED_INIT(LOGIC_LED_OFF)

#define DEMO_ADC16_CHANNEL 26U
#define DEMO_ADC16_BASEADDR ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U

#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 0U /*PTE20, ADC0_SE0 */

#define DEMO_DMA_BASEADDR DMA0
#define DEMO_DMA_IRQ_ID DMA0_IRQn
#define DEMO_DMA_IRQ_HANDLER_FUNC DMA0_IRQHandler
#define DEMO_DMA_CHANNEL 0U
#define DEMO_DMA_ADC_SOURCE kDmaRequestMux0ADC0

#define ADC16_RESULT_REG_ADDR (uint32_t)(&ADC0->R[0]) /* Get ADC16 result register address */

#define DEMO_DMAMUX_BASEADDR DMAMUX0

#define DEMO_ADC16_SAMPLE_COUNT 256   /* The ADC16 sample count */

adc16_config_t adcUserConfig;
adc16_channel_config_t adcChnConfig;

#define DECAY_COEFF 8

#define MAXVALUE 65536
#define STEPSIZE 512

int no_of_lookup_entries = MAXVALUE/STEPSIZE;
double abs_value=0;
int lookupIndex=0;
static int LookupTable[128];

//Fills the table
void LookuptableInit(){
	for(int i=0; i<no_of_lookup_entries; i++){
		if(i == 0){
			abs_value = STEPSIZE;
		}
		else{
			abs_value = i*STEPSIZE;
		}
		LookupTable[i] = 20*log10(abs_value/MAXVALUE);
		PRINTF("LUT[%d]:%d\r\n", i, LookupTable[i]);
	}
}

#define ADC_Polling 0
void ADC0_Init(){

	ADC16_GetDefaultConfig(&adcUserConfig);

	//Select the clock source as the bus clock
	adcUserConfig.clockSource = 0U;

	//Disable Asynchronous clock
	adcUserConfig.enableAsynchronousClock = false;

	//Choose the clock divisor
	adcUserConfig.clockDivider = kADC16_ClockDivider1;

	//Select 16 bits of resolution
	adcUserConfig.resolution = kADC16_Resolution16Bit;

	//Pass these values into the intialization function for the registers to be set
	ADC16_Init(DEMO_ADC16_BASE, &adcUserConfig);

	//Enable the software mode so the DMA can use the ADC as the source addr
	ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false);

	//Select channel number 0
	adcChnConfig.channelNumber = 0u;

	//Disable interrupts
	adcChnConfig.enableInterruptOnConversionCompleted = false;

//----------------------------------Manual Register Selection Method------------------------------------------------------
//	SIM->SCGC5 |= SIM_SCGC5_PORTE(1);  //Enable PORTE
//	PORTE->PCR[20] |= PORT_PCR_MUX(0); //Setting PORTE(PTE20) processor pin 13 as analog input
//	//System Clock Gating Control Register 6
//
//	//ADC Clock Gate Control--This bit controls the clock gate to the  ADC module
//	SIM->SCGC6 |= SIM_SCGC6_ADC0(1);
//
//	//Set DIFF=0 to choose single ended mode
//	//Conversion mode selection
//    ADC0->CFG1 |= ADC_CFG1_MODE(3);
//
//    //Select bus clock as the clock source(24 Mhz)
//    ADC0->CFG1 |= ADC_CFG1_ADICLK(0);
//
//    //Set the  divide ratio to 3 which sets internal clock clock rate as (input clock)/8 = 24/4 = 6Mhz?
//    ADC0->CFG1 |= ADC_CFG1_ADIV(3);
//    //reset SC1
//    ADC0->SC1[0] = 0;
//
//    //Configures the ADC to operate in differential mode. When enabled, this mode automatically selects from
//    //the differential channels, and changes the conversion algorithm and the number of cycles to complete a
//    //conversion.
//    ADC0->SC1[0] |= ADC_SC1_DIFF(0);
//
//    //Set ADC to operate in  single-ended 16-bit continuous conversion mode
//    ADC0->SC3 |= ADC_SC3_AVGE_MASK;
//    ADC0->SC3 |= ADC_SC3_ADCO_MASK;
//
//    //Enable DMA
//    ADC0->SC2 |= ADC_SC2_DMAEN_MASK;
//
//    //Select software trigger mode
//    ADC0->SC2 |= ADC_SC2_ADTRG(0);
//   // ADC0->R[1] |= ADC_R_D(1);

//#if ADC_Polling
//
//#else
//    NVIC_EnableIRQ(ADC0_IRQn);

//    ADC0->SC1[0] |= ADC_SC1_AIEN_MASK;
//#endif
}

static uint32_t g_adc16SampleDataArray[256]; /* ADC value array */
static uint32_t g_adc16SampleDataArray2[256]; /* ADC value array */
dma_handle_t g_DMA_Handle;                                       /* Dma handler */
dma_transfer_config_t g_transferConfig;                          /* Dma transfer config */

static uint32_t Buffer_Full_State = 0;

void DMA_Initialization(){
//---------------------DMAMUX------------------------------------------------
	//DMAMUX_Init(DEMO_DMAMUX_BASEADDR);

	//DMA Mux Clock Gate Control
	SIM->SCGC6 |= SIM_SCGC6_DMAMUX(1);

//	Set the channel 0 source to be the ADC0
	DMAMUX0->CHCFG[0] |= DMAMUX_CHCFG_SOURCE(kDmaRequestMux0ADC0);

//	Enables the DMAMUX channel
	DMAMUX0->CHCFG[0] |= DMAMUX_CHCFG_ENBL_MASK;

//-------------------DMA-----------------------------------------------------

	//DMA_Init(DEMO_DMA_BASEADDR);

	//DMA Clock Gate Control
	SIM->SCGC7 |= SIM_SCGC7_DMA(1);
	/* Set source address */
	DMA0->DMA[0].SAR = (uint32_t)(&ADC0->R[0]);

	/* Set destination address */
	if (Buffer_Full_State == 0){
		DMA0->DMA[0].DAR = (uint32_t)&g_adc16SampleDataArray;
	}
	else{
		DMA0->DMA[0].DAR = (uint32_t)&g_adc16SampleDataArray[128];
	}

//	PRINTF("Address1:%p\r\n", &g_adc16SampleDataArray);
//	PRINTF("Address2:%p\r\n", &g_adc16SampleDataArray[128]);
//	PRINTF("DMA_ADDRESS:%p\r\n", DMA0->DMA[0].DAR);
	//This field contains the number of bytes yet to be transferred for a given block
	DMA0->DMA[0].DSR_BCR = DMA_DSR_BCR_BCR(512);

	//Clear the source and destination values before setting.
	DMA0->DMA[0].DCR &= ~(DMA_DCR_DSIZE_MASK | DMA_DCR_DINC_MASK | DMA_DCR_SSIZE_MASK | DMA_DCR_SINC_MASK);

	//Pass the source and destination sizes
	DMA0->DMA[0].DCR |= DMA_DCR_DSIZE(kDMA_Transfersize32bits);

	DMA0->DMA[0].DCR |= DMA_DCR_SSIZE(kDMA_Transfersize32bits);

	//Determine whether the DMA should increment from where and to what it passes
	DMA0->DMA[0].DCR |= DMA_DCR_DINC(true);

	DMA0->DMA[0].DCR |= DMA_DCR_SINC(false);

	//Enable Interrupt on transfer
	DMA0->DMA[0].DCR |= DMA_DCR_EINT(true);

	/* Enable async DMA request. */
//	DMA0->DMA[0].DCR = (DMA0->DMA[0].DCR & (~DMA_DCR_EADREQ_MASK)) | DMA_DCR_EADREQ(true);

	/* Forces a single read/write transfer per request. */
	DMA0->DMA[0].DCR = (DMA0->DMA[0].DCR & (~DMA_DCR_CS_MASK));
	DMA0->DMA[0].DCR |= DMA_DCR_CS(true);

	//Enables peripheral request to initiate transfer.
	DMA0->DMA[0].DCR |= DMA_DCR_ERQ_MASK;

	ADC0->SC2 |= ADC_SC2_DMAEN(1);

//	DMA0->DMA[0].DCR |= DMA_DCR_START_MASK;

	/* Enable IRQ. */
    NVIC_EnableIRQ(DMA0_IRQn);
}

void ADC0_IRQHandler(){
	PRINTF("ADC VALUE:%d\r\n", ADC0->R[0]);
}

uint32_t testBOI = 0;
int switchBuf = 0;


static uint16_t MaxVal=0;

void ADC_Max_Val(){
	int Decay_State = 0;
	if(Buffer_Full_State == 0){
		for(int i = 0; i < sizeof(g_adc16SampleDataArray)/8; i++){
			if (g_adc16SampleDataArray[i] > MaxVal){
				MaxVal = g_adc16SampleDataArray[i];
				PRINTF("Buffer[%d]:%d\r\n", i, g_adc16SampleDataArray[i]);
				Decay_State = 1;
			}
		}
	}
	else if(Buffer_Full_State == 1){
		for(int i = 127; i < sizeof(g_adc16SampleDataArray)/8; i++){
			if (g_adc16SampleDataArray[i] > MaxVal){
				MaxVal = g_adc16SampleDataArray[i];
				PRINTF("Buffer[%d]:%d\r\n", i, g_adc16SampleDataArray[i]);
				Decay_State = 1;
			}
		}
	}
	if (Decay_State == 0){
		MaxVal = (MaxVal*DECAY_COEFF)/10;
	}

	//During ADC runtime
	uint16_t LookupIndex = (MaxVal)/STEPSIZE;
	PRINTF("LUT INDEX:%d", LookupIndex);
	int dbValue = LookupTable[LookupIndex];

	PRINTF("Max ADC Val:%d\r\n", MaxVal);

	PRINTF("dbVal:%d\r\n", dbValue);
}

void DMA0_IRQHandler(){
	PRINTF("-------------------MADE IT TO DMA---------------------\r\n");
	PRINTF("Address1:%p\r\n", &g_adc16SampleDataArray);
	PRINTF("Address2:%p\r\n", &g_adc16SampleDataArray[128]);
	DMA0->DMA[0].DSR_BCR |= DMA_DSR_BCR_DONE_MASK;

	PRINTF("Size of array:%d\r\n", sizeof(g_adc16SampleDataArray)/8);
	for(int i = 0; i < sizeof(g_adc16SampleDataArray)/4; i++){
		PRINTF("DMA ADC BUF VAL[%d]:%d\r\n", i, g_adc16SampleDataArray[i]);
	}
//		DMA0->DMA[0].DSR_BCR &= ~DMA_DSR_BCR_DONE_MASK;
//
//		DMA0->DMA[0].DSR_BCR = DMA_DSR_BCR_BCR(sizeof(g_adc16SampleDataArray2)/2);
//
//		DMA0->DMA[0].DAR = (uint32_t)&g_adc16SampleDataArray2;
//
//		DMA0->DMA[0].DCR |= DMA_DCR_ERQ_MASK;
	ADC_Max_Val();
	if (Buffer_Full_State == 0){
		Buffer_Full_State = 1;
	}
	else if (Buffer_Full_State == 1){
		Buffer_Full_State = 0;
	}

	DMA_Initialization();
	ADC0_Init();
	switchBuf = 1;
	int test = 5;
}

int main(void) {

  	/* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
  	/* Init FSL debug console. */
    BOARD_InitDebugConsole();


    LED_INIT();
    LookuptableInit();
    ADC0_Init();
    DMA_Initialization();

    /* Force the counter to be placed into memory. */
    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
    	int test = 0;
    	ADC16_SetChannelConfig(DEMO_ADC16_BASEADDR, 0, &adcChnConfig);
//    	while( !(ADC0->SC1[0] & ADC_SC1_COCO_MASK)){}
//		PRINTF("ADC VALUE:%d", ADC0->R[0]);
    	//GPIO_TogglePinsOutput(BOARD_LED_RED_GPIO, 1U << BOARD_LED_RED_GPIO_PIN); /*!< Toggle on target LED_RED */
    }
    return 0 ;
}

//--------------------------------------------OLD CODE-------------------------------------------
//void ADC_Init(){
//	adc16_config_t adcUserConfig;
//    adc16_channel_config_t adcChnConfig;
//    /*
//    * Initialization ADC for
//    * 16bit resolution, interrupt mode, hw trigger enabled.
//    * normal convert speed, VREFH/L as reference,
//    * disable continuous convert mode.
//    */
//    ADC16_GetDefaultConfig(&adcUserConfig);
//    adcUserConfig.resolution = kADC16_ResolutionSE16Bit;
//    adcUserConfig.enableContinuousConversion = true;
//    adcUserConfig.clockSource = kADC16_ClockSourceAsynchronousClock;
//
//    adcUserConfig.clockDivider = kADC16_ClockDivider2;
//
//    ADC16_Init(DEMO_ADC16_BASEADDR, &adcUserConfig);
//
//    adcChnConfig.channelNumber = DEMO_ADC16_CHANNEL;
//
//    adcChnConfig.enableInterruptOnConversionCompleted = true;
//	/* Configure channel 0 */
//	ADC16_SetChannelConfig(DEMO_ADC16_BASEADDR, DEMO_ADC16_CHANNEL_GROUP, &adcChnConfig);
//
//    //Enable ADC0 Interrupts
////	NVIC_EnableIRQ(ADC0_IRQn);
//
////	ADC0->SC1[0] |= ADC_SC1_AIEN_MASK;
//
//}
//--------------------------------------------------------------------------------------------------
